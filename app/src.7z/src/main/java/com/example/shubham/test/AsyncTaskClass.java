package com.example.shubham.test;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.ImageView;

import java.io.IOException;
import java.net.URL;

/**
 * Created by Shubham on 17-03-2016.
 */
public class AsyncTaskClass extends AsyncTask<Void, Void, Bitmap> {
    String url;
    ViewHolder holder;
    String TAG = "ÄsyncTaskClass";

    public AsyncTaskClass(String imageUrl, ViewHolder holder) {
        url = imageUrl;
        this.holder = holder;
    }

    @Override
    protected void onPostExecute(Bitmap result) {
        if (result != null) {
            holder.image.setImageBitmap(result);
        }
    }

    @Override
    protected Bitmap doInBackground(Void... params) {
        Bitmap bitmap;
        try {
            URL imageURL = new URL(url);
            Log.e(TAG, "doInBackground : Starting download");
            bitmap = BitmapFactory.decodeStream(imageURL.openStream());
        } catch (IOException e) {
            Log.e(TAG, "Downloading Image Failed");
            bitmap = null;
        }
        return bitmap;
    }
}
