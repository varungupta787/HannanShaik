package com.example.shubham.test;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

/**
 * Created by Shubham on 16-03-2016.
 */
public class AdapterClass extends RecyclerView.Adapter<ViewHolder> {
    int SIMPLE_CARD = 0, CHECKIN_CARD = 1;
    private LayoutInflater inflater;
    private Context mContext;
    private ArrayList<Data.ViewData> viewData;
    private String TAG = "ÄdapterClass";

    AdapterClass(Context context, ArrayList<Data.ViewData> viewData) {
        inflater = LayoutInflater.from(context);
        mContext = context;
        this.viewData = viewData;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        int layout;
        if (viewType == SIMPLE_CARD) {
            layout = R.layout.simple_card;
        } else {
            layout = R.layout.checkin_card;
        }
        view = inflater.inflate(layout, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final Data.ViewData data = viewData.get(position);
        holder.title.setText(data.getTitle());
        if (null != holder.content)
            holder.content.setText(data.getContent());
        if (null != holder.location_url) {
            holder.location_url.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(data.getLocationUrl()));
                    mContext.startActivity(browserIntent);
                }
            });
        }
        if (null != holder.image) {
            Log.e(TAG,"URL : "+data.getImageUrl());
            new AsyncTaskClass(data.getImageUrl(),holder).execute();
        }
        if (null != holder.more_images) {
            holder.more_images.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(data.getMoreImageURl()));
                    mContext.startActivity(browserIntent);
                }
            });
        }
    }

    @Override
    public int getItemViewType(int position) {
        if (viewData.get(position).getType().equalsIgnoreCase("simple_card")) {
            return SIMPLE_CARD;
        } else {
            return CHECKIN_CARD;
        }
    }

    @Override
    public int getItemCount() {
        return viewData.size();
    }

}